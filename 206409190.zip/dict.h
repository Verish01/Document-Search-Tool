// Do NOT add any other includes
#include <string> 
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class AVLNode{
    public:
        string word;
        int count;
        AVLNode* left;
        AVLNode* right;
        int height;
        AVLNode();
};

class Dict {
private:
    // You can add attributes/helper functions here
    AVLNode* root;
    int getHeight(AVLNode* node);
    int getBalanceFactor(AVLNode* node);
    AVLNode* getroot();
    AVLNode* rightRotate(AVLNode* y);
    AVLNode* leftRotate(AVLNode* x);
    AVLNode* insert(AVLNode* node, string word);
    AVLNode* search(AVLNode* node, string word);
    void inorder();

public: 
    /* Please do not touch the attributes and 
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    Dict();

    ~Dict();

    void insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence);

    int get_word_count(string word);

    void dump_dictionary(string filename);

    /* -----------------------------------------*/
};
