// Do NOT add any other includes
#include "search.h"
#include "Node.h"

SearchEngine::SearchEngine(){
    texts = {};
}

SearchEngine::~SearchEngine(){

}

const int prime = 101;
const int mod = 32768;

int pow(int prime, int pwr){
    int ans = 1;
    for(int i=0; i<pwr; i++){
        ans = (ans*prime)%mod;
    }
    return ans%mod;
}

int calculateHash(const std::string& str, int length) {
    int hash = 0;
    for (int i = 0; i < length; i++) {
        int elt = (int)str[i];
        hash = (hash + elt)%mod;
    }
    return hash;
}

// Function to search for a substring in the text using Rabin-Karp algorithm
void SearchEngine::rabinKarpSearch(string text, string pattern, vector<int> loc, Node* &node, int& n_matches) {
    int textLength = text.length();
    int patternLength = pattern.length();
    int patternHash = calculateHash(pattern, patternLength);
    int textHash = calculateHash(text, patternLength);
    Node* head = NULL;
    for (int i = 0; i <= textLength - patternLength; i++) {
        if (patternHash == textHash) {
            bool match = true;
            for (int j = 0; j < patternLength; j++) {
                if (text[i + j] != pattern[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                Node* newNode = new Node(loc[0], loc[1], loc[2], loc[3], i);
                if (!head) {
                    head = newNode;
                } else {
                    node->right = newNode;
                    newNode->left = node;
                }
                node = newNode;
                n_matches++;
            }
        }
        if (i < textLength - patternLength) {
            textHash = ((textHash - text[i]) + text[i + patternLength]) % mod;
        }
    }
    node = head;
}

void SearchEngine::insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence){
    vector<int> loc(4);
    loc[0] = book_code;
    loc[1] = page;
    loc[2] = paragraph;
    loc[3] = sentence_no;
    texts.push_back({loc, sentence});
}

void Print(Node* node){
    Node* temp = node;
    while(temp!=NULL){
        cout << temp->book_code <<","<< temp->page << "," << temp->paragraph <<","<< temp->sentence_no <<","<< temp->offset << endl;
        temp = temp->right;
    }
}

Node* SearchEngine::search(string pattern, int& n_matches){
    Node* combinedListHead = NULL;
    Node* combinedListTail = NULL;
    int n = texts.size();
    for (int i = 0; i < n; i++) {
        Node* node = NULL;
        rabinKarpSearch(texts[i].second, pattern, texts[i].first, node, n_matches);

        if (combinedListTail) {
            combinedListTail->right = node;
            if (node) {
                node->left = combinedListTail;
            }
            while (combinedListTail->right) {
                combinedListTail = combinedListTail->right;
            }
        } else {
            combinedListHead = node;
            combinedListTail = node;
        }
    }
    return combinedListHead;
}


